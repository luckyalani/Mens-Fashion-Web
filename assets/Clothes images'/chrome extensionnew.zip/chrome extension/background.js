chrome.action.onClicked.addListener(function (tab) {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["starter.js"],
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "vce-get-user-data") {
    chrome.cookies.get(
      { url: "https://visualcsseditor.com/", name: "vce-token" },
      function (cookie) {
        if (cookie) {
          fetch("https://visualcsseditor.com/api/", {
            method: "GET",
            credentials: "include",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${cookie.value}`,
            },
          })
            .then((response) => response.json())
            .then((data) => {
              sendResponse(data);
            })
            .catch((error) => {
              sendResponse({
                status: "error",
                message: "Error fetching data.",
              });
            });
        } else {
          sendResponse({ status: "error", message: "No token cookie found." });
        }
        return true;
      }
    );
    return true;
  }
});

function initializeStylingLimit() {
  chrome.cookies.get({ url: 'https://visualcsseditor.com', name: 'vce-style-counts' }, function(cookieCounts) {
    chrome.cookies.get({ url: 'https://visualcsseditor.com', name: 'vce-last-reset-date' }, function(cookieDate) {
      const today = new Date();
      const lastResetDate = cookieDate ? new Date(cookieDate.value) : new Date();
      const diffTime = Math.abs(today - lastResetDate);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays >= 30 || !cookieCounts) {
        const expiryDate = new Date();
        expiryDate.setFullYear(expiryDate.getFullYear() + 10); // Set for 10 year ahead

        chrome.cookies.set({
          url: 'https://visualcsseditor.com',
          name: 'vce-style-counts',
          value: '0',
          expirationDate: expiryDate.getTime() / 1000,
        });

        chrome.cookies.set({
          url: 'https://visualcsseditor.com',
          name: 'vce-last-reset-date',
          value: today.toISOString(),
          expirationDate: expiryDate.getTime() / 1000,
        });
      }
    });
  });
}

function setStyleEditsCount(newCount, callback) {
  const expiryDate = new Date();
  expiryDate.setFullYear(expiryDate.getFullYear() + 10); // Set for 10 year ahead

  chrome.cookies.set({
    url: 'https://visualcsseditor.com',
    name: 'vce-style-counts',
    value: newCount.toString(),
    expirationDate: expiryDate.getTime() / 1000,
  }, function() {
    callback({ "vce-style-counts": newCount });
  });
}

function getStyleEditsCount(callback) {
  chrome.cookies.get({ url: 'https://visualcsseditor.com', name: 'vce-style-counts' }, function(cookie) {
    const counts = cookie ? parseInt(cookie.value, 10) : 0;
    callback({ "vce-style-counts": counts });
  });
}

initializeStylingLimit();

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "vce-set-style-edits-count") {
    setStyleEditsCount(request.newCount, sendResponse);
    return true;
  } else if (request.action === "vce-get-style-edits-count") {
    getStyleEditsCount(sendResponse);
    return true;
  }
});